import { motion } from "framer-motion";
import { CheckCircle2, Award, Users, Zap } from "lucide-react";

const AboutSection = () => {
  const highlights = [
    "ISO 9001:2015 Certified Operations",
    "Government of India Recognized Exporter",
    "FIEO Member & Compliant",
    "Sustainable Trade Practices",
  ];

  const values = [
    {
      icon: Award,
      title: "Excellence",
      description: "Uncompromising quality in every transaction",
    },
    {
      icon: Users,
      title: "Trust",
      description: "Building long-term partnerships globally",
    },
    {
      icon: Zap,
      title: "Innovation",
      description: "Leveraging technology for seamless trade",
    },
  ];

  return (
    <section id="about" className="py-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              About <span className="text-gradient">Hanok</span>
            </h2>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              Since our founding, Hanok Global Trader has been at the forefront of international commerce, 
              facilitating seamless trade connections across continents. Our commitment to excellence and 
              sustainable practices has positioned us as a trusted partner for businesses worldwide.
            </p>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              With expertise spanning agriculture, minerals, and industrial sectors, we deliver comprehensive 
              trade solutions backed by cutting-edge logistics and unwavering quality standards.
            </p>

            {/* Highlights */}
            <div className="space-y-4 mb-8">
              {highlights.map((highlight, index) => (
                <motion.div
                  key={highlight}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="flex items-center space-x-3"
                >
                  <CheckCircle2 className="w-6 h-6 text-secondary flex-shrink-0" />
                  <span className="text-foreground font-medium">{highlight}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Content - Values */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-6"
          >
            {values.map((value, index) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                className="p-8 bg-card rounded-lg shadow-elegant border border-border group hover:border-secondary transition-smooth"
              >
                <div className="flex items-start space-x-4">
                  <div className="w-14 h-14 bg-gradient-gold rounded-lg flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-smooth">
                    <value.icon className="w-7 h-7 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-card-foreground mb-2 group-hover:text-accent transition-smooth">
                      {value.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {value.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
