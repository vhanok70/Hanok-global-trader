import { motion } from "framer-motion";
import { Wheat, Gem, Factory } from "lucide-react";
import agricultureImg from "@/assets/agriculture-sector.jpg";
import mineralsImg from "@/assets/minerals-sector.jpg";
import industrialImg from "@/assets/industrial-sector.jpg";

const SectorsSection = () => {
  const sectors = [
    {
      icon: Wheat,
      title: "Agriculture",
      description: "Premium grains, pulses, and agricultural commodities sourced from trusted farms worldwide",
      image: agricultureImg,
      stats: "5000+ Tons Monthly",
    },
    {
      icon: Gem,
      title: "Minerals & Metals",
      description: "High-grade minerals, ores, and refined metals meeting international quality standards",
      image: mineralsImg,
      stats: "30+ Countries",
    },
    {
      icon: Factory,
      title: "Industrial Machinery",
      description: "Advanced manufacturing equipment and industrial solutions for global enterprises",
      image: industrialImg,
      stats: "500+ Clients",
    },
  ];

  return (
    <section id="sectors" className="py-24 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-foreground mb-4">
            Our <span className="text-gradient">Sectors</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Leading the way in global trade across multiple industries with unmatched expertise
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {sectors.map((sector, index) => (
            <motion.div
              key={sector.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ y: -10 }}
              className="group relative overflow-hidden rounded-lg shadow-elegant bg-card cursor-pointer"
            >
              {/* Image */}
              <div className="relative h-64 overflow-hidden">
                <img
                  src={sector.image}
                  alt={sector.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-smooth"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/50 to-transparent opacity-80 group-hover:opacity-90 transition-smooth" />
                
                {/* Icon */}
                <div className="absolute top-6 left-6 w-14 h-14 bg-gradient-gold rounded-lg flex items-center justify-center shadow-glow group-hover:scale-110 transition-smooth">
                  <sector.icon className="w-8 h-8 text-primary" />
                </div>

                {/* Stats Badge */}
                <div className="absolute top-6 right-6 px-4 py-2 bg-secondary/90 backdrop-blur-sm rounded-full text-primary text-sm font-semibold">
                  {sector.stats}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-2xl font-bold text-card-foreground mb-3 group-hover:text-accent transition-smooth">
                  {sector.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {sector.description}
                </p>
              </div>

              {/* Hover Effect Border */}
              <div className="absolute inset-0 border-2 border-transparent group-hover:border-secondary rounded-lg transition-smooth pointer-events-none" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SectorsSection;
