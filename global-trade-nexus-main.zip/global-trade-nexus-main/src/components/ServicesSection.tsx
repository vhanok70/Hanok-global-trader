import { motion } from "framer-motion";
import { Ship, FileCheck, TrendingUp, HeadphonesIcon, Shield, Globe } from "lucide-react";

const ServicesSection = () => {
  const services = [
    {
      icon: Ship,
      title: "Global Logistics",
      description: "End-to-end supply chain management with real-time tracking and optimized routes",
    },
    {
      icon: FileCheck,
      title: "Compliance & Documentation",
      description: "Complete handling of customs, certifications, and regulatory requirements",
    },
    {
      icon: TrendingUp,
      title: "Market Intelligence",
      description: "Data-driven insights and market analysis for informed trading decisions",
    },
    {
      icon: Shield,
      title: "Quality Assurance",
      description: "Rigorous quality control and international standard certifications",
    },
    {
      icon: Globe,
      title: "Multi-Country Operations",
      description: "Established presence in 50+ countries with local expertise",
    },
    {
      icon: HeadphonesIcon,
      title: "24/7 Support",
      description: "Round-the-clock customer service and dedicated account management",
    },
  ];

  return (
    <section id="services" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold text-foreground mb-4">
            Premium <span className="text-gradient">Services</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Comprehensive solutions designed to streamline your global trade operations
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="p-8 bg-card rounded-lg shadow-elegant hover:shadow-glow transition-smooth border border-border group"
            >
              <div className="w-16 h-16 bg-gradient-gold rounded-lg flex items-center justify-center mb-6 group-hover:scale-110 transition-smooth">
                <service.icon className="w-8 h-8 text-primary" />
              </div>
              <h3 className="text-2xl font-bold text-card-foreground mb-3 group-hover:text-accent transition-smooth">
                {service.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
